async function isRegister(){
    const error = document.getElementById("error")
    const register = document.getElementById("registerBtn")


    isRegistration = !isRegisteration
    register.innerText = isRegistration ? 'Sign in' : 'Sign up'
    document.querySelector('#auth > div h2').innerText = isRegisteration ? 'Sign up' : 'Login'
    document.querySelector('.register-content p').innerText = isRegisteration ? 'Already have an account?' : 'Don\'t have an account?' 
    document.querySelector('.register-content button'),innerText = isRegisteration ? 'Sign in' : 'Sign up'
}

async function authenticate(){
    const error = document.getElementById('error')
    const auth = document.getElementById('authBtn')
    const emailVal = email.value 
    const passVal = password.value

    if (
        isLoading ||
        isAuthenticating ||
        !emailVal ||
        !passVal ||
        passVal.length < 6 ||
        !emailVal.includes('@')
    ) { return }

    error.style.display = 'none'
    isAuthenticating = true
    auth.innerText = 'Authenticating...'

    try{
        let data
        if (isRegisteration) {
            const response = await fetch({
           method: 'POST',
           headers: {'Content-Type': 'application/json'},
           body: JSON.stringify({username: emailVal, password: passVal })
            })

            data = await response.json()
        } else {

            const response = await fetch({
                method: 'POST',
                headers: {'Content-Type' : 'application/json' },
                body: JSON.stringify({ username: emailVal, password: passVal})
            })

            data = await response.json()
        }

        if (data.token){
            token = data.token
            localStorage.setItem('token', token)

            auth.innerText = 'Loading...'

        } else {
            throw error('Failed to authenticate...')
        }

    } catch (err) {
        console.log(err.message)
        error.innerText = err.message
        error.style.display = 'block'
    } finally {
        auth.innerText = 'Submit'
        isAuthenticating = false
    }
}

function logout (){
    
}