import os
import re
from flask import Flask, render_template, request, send_from_directory
from openai import OpenAI

app = Flask(__name__)
client = OpenAI(
    base_url="https://integrate.api.nvidia.com/v1",
    api_key=os.environ.get(
        "NVIDIA_API_KEY",
        "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",
    ),
)
MODEL = os.environ.get("NVIDIA_MODEL", "deepseek-ai/deepseek-v4-flash-0731")


def chat_text(messages, max_tokens=4096):
    completion = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        temperature=1,
        top_p=0.95,
        max_tokens=max_tokens,
        extra_body={
            "chat_template_kwargs": {
                "thinking": True,
                "reasoning_effort": "high",
            }
        },
        stream=False,
        timeout=120,
    )
    message = completion.choices[0].message
    content = (message.content or "").strip()
    if content:
        return content
    reasoning = getattr(message, "reasoning", None) or getattr(
        message, "reasoning_content", None
    )
    if reasoning:
        return str(reasoning).strip()
    return ""


def extract_profit_values(graph_data):
    numbers = re.findall(r"-?\d+(?:\.\d+)?", graph_data)
    return [float(n) for n in numbers]


def profit_is_steadily_decreasing(values, min_points=4, min_drops=3):
    if len(values) < min_points:
        return False

    recent = values[-min_points:]
    drops = sum(1 for i in range(1, len(recent)) if recent[i] < recent[i - 1])
    if drops >= min_drops:
        return True

    midpoint = len(values) // 2
    first_avg = sum(values[:midpoint]) / midpoint
    second_avg = sum(values[midpoint:]) / (len(values) - midpoint)
    falling_overall = second_avg < first_avg * 0.95
    return falling_overall and drops >= min_drops - 1


def declining_profit_advice(business, graph_data):
    return chat_text(
        [
            {
                "role": "user",
                "content": (
                    f"Profit margins for {business} have been steadily decreasing.\n"
                    f"Data:\n{graph_data}\n\n"
                    "Give a short summary of what is going wrong, then list concrete "
                    "ways to raise profit and the specific areas to fix. Keep it practical."
                ),
            }
        ],
        max_tokens=1024,
    )


@app.route("/")
@app.route("/login", methods=["GET", "POST"])
@app.route("/login.html", methods=["GET", "POST"])
def login():
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
@app.route("/register.html", methods=["GET", "POST"])
def register():
    return render_template("login.html")


@app.route("/home")
@app.route("/home.html")
def home():
    return send_from_directory(os.path.join(app.root_path, "main"), "home.html")


@app.route("/chart")
@app.route("/chart.html")
@app.route("/new.html")
def chart():
    return render_template("chart.html")


@app.route("/favicon.ico")
def favicon():
    return ("", 204)


@app.route("/ask", methods=["GET", "POST"])
@app.route("/ask.html", methods=["GET", "POST"])
def ask():
    answer = None
    if request.method == "POST":
        question = request.form.get("question", "").strip()
        if question:
            try:
                answer = chat_text(
                    [{"role": "user", "content": question}],
                    max_tokens=1024,
                )
            except Exception as e:
                answer = f"Error generating answer: {e}"

    return render_template("ask.html", answer=answer)


@app.route("/graph", methods=["GET", "POST"])
@app.route("/graph-summary", methods=["GET", "POST"])
@app.route("/graph.html", methods=["GET", "POST"])
def graphSummary():
    answer = None
    alert = False
    business = ""
    graph_data = ""

    if request.method == "POST":
        graph_data = request.form.get("graph_data", "").strip()
        business = request.form.get("business", "").strip() or "the business"
        if graph_data:
            values = extract_profit_values(graph_data)
            alert = profit_is_steadily_decreasing(values)
            if alert:
                try:
                    answer = declining_profit_advice(business, graph_data)
                except Exception as e:
                    answer = f"Error generating answer: {e}"

    return render_template(
        "graph.html",
        answer=answer,
        alert=alert,
        business=business,
        graph_data=graph_data,
    )


@app.route("/ideas", methods=["GET", "POST"])
@app.route("/ideas.html", methods=["GET", "POST"])
def projectIdea():
    answer = None
    if request.method == "POST":
        business = request.form.get("business", "").strip() or "the business"
        graph_data = request.form.get("graph_data", "").strip()
        if business:
            try:
                answer = chat_text(
                    [
                        {
                            "role": "user",
                            "content": (
                                f"Here is the type of business for {business}. "
                                f"Create a project idea based on this data: {graph_data}. "
                                "Suggest projects the business could do based on the income "
                                "they are receiving, and tailor the ideas to that."
                            ),
                        }
                    ],
                    max_tokens=1024,
                )
            except Exception as e:
                answer = f"Error generating answer: {e}"

    return render_template("ideas.html", answer=answer)


if __name__ == "__main__":
    app.run(debug=True)
